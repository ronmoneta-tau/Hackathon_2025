import os
import nbformat
from nbconvert import PythonExporter

def convert_ipynb_to_py(input_ipynb, output_py):
    # Load the input notebook
    with open(input_ipynb, 'r', encoding='utf-8') as file:
        nb = nbformat.read(file, as_version=4)

    # Convert to Python script
    py_exporter = PythonExporter()
    body, _ = py_exporter.from_notebook_node(nb)

    # Write the converted script
    with open(output_py, 'w', encoding='utf-8') as file:
        file.write(body)

def remove_consecutive_empty_lines(lines):
    # Remove consecutive empty lines from a list of lines
    new_lines = []
    prev_line_empty = False
    for line in lines:
        current_line_empty = not line.strip()
        if not (current_line_empty and prev_line_empty):
            new_lines.append(line)
        prev_line_empty = current_line_empty
    return new_lines

def customize_script(input_py, output_py, inFile, outFile):
    # Read the input Python script
    with open(input_py, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # Prepare the new script lines
    new_lines = ["def MakeSSTMobileSummary(inFile):\n"]  # Define the new function
    for line in lines:
        if line.startswith('# In[') and line.endswith(']:\n'):
            continue  # Skip '# In[something]:' lines

        if 'display(' in line:
            continue  # Skip lines containing 'display'

        if 'pd.read_csv' in line:
            line = f"    df = pd.read_csv(inFile)  # Modified to read from inFile\n"
        elif 'df_result.to_csv(' in line:
            line = f"    return df_result # Modified to save to outFile\n"
        else:
            line = '    ' + line  # Indent the line to be inside the function
        new_lines.append(line)

    # Remove consecutive empty lines
    new_lines = remove_consecutive_empty_lines(new_lines)

    # Write the modified lines to the output Python script
    with open(output_py, 'w', encoding='utf-8') as file:
        file.writelines(new_lines)

def convert_and_clean_notebook(input_ipynb, intermediate_py, final_output_py, inFile, outFile):
    # Convert .ipynb to .py
    convert_ipynb_to_py(input_ipynb, intermediate_py)

    # Customize the script with inFile and outFile
    customize_script(intermediate_py, final_output_py, inFile, outFile)

    # Optionally, remove the intermediate file
    os.remove(intermediate_py)

    print(f"Conversion and customization complete. The final script is saved as '{final_output_py}'.")

# Define your file names
input_ipynb = 'sst-mobile-processing-demo.ipynb'
intermediate_py = 'intermediate_script.py'
final_output_py = 'MakeSSTMobileSummary.py'

# Define your inFile and outFile
inFile = 'path/to/your/input.csv'
outFile = 'path/to/your/output.csv'

# Convert and clean the notebook
convert_and_clean_notebook(input_ipynb, intermediate_py, final_output_py, inFile, outFile)
