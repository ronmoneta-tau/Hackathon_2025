# SST Summary File Generator

 This code reads in a Stop Signal Delay Task (SST) data file and produces a summary file.

 ## Dependencies
All code is written in Python 3.7, and required python packages are:
- numpy
- pandas
- os
- glob
- argparse

 ## Code location
 These scripts can be found on the SDAN1 shared drive in:
 ```bash
 $sdan1/DaveJangraw/BehaviorProcessing/CognitiveControlBehavioralTask//StopSignalSummaryFile

   ```
 ## Usage
Note that details and filenames were chosen to match existing examples found in $sdan1/Data/Cognitive Control Behavioral Tasks/StopSignalTask/Processing/Data/input. I tried it out on a couple subjects found there, and the outputs seemed to match the old ones. But if you’d like anything changed, just say the word.

1. Make sure you have Anaconda installed on your computer (the 3.7 version) so you can run python scripts.
2. Make sure the **sdan1** shared drive is mounted on your machine (i.e., you’re connected to it).
3. Place any xlsx input files you’d like to process in the folder $sdan1/Data/Cognitive Control Behavioral Tasks/StopSignalTask/Processing/Data/input. The extension of files should be 'xlsx' (case-sensitive).
4. Open a terminal (MAC) or Anaconda prompt (Windows) and navigate to the folder where the code sits.

    To get help on how to use it, type:

       python3 AutoMakeSSTSummaryFile.py –help

    This will give you info about the inputs or ‘flags’, which are:

     - --id \<ID\> : \<ID\> can be one or more file names, or ‘all’ to detect and process all files in the project folder automatically (Don't include extensions. For example, if your input file is **testinput.xlsx**, only use **--id testinput**)
     - --overwrite: If this flag is included, any current data in the output folder will be deleted before the script runs. If it’s not, any files that already have output folders will be skipped.
5. Run the code. The results will be saved here:

       $sdan1/Data/Cognitive Control Behavioral Tasks/StopSignalTask/Processing/Data/output

Here are example commands for running commands.

- (Option1): This example will run all filess detected in the input folder with default settings.

        python3 AutoMakeSSTSummaryFile.py --id all


- (Option2): This example will run two specific files and overwrite their data (testinput1.xlsx and 20053.xlsx).

        python3 AutoMakeSSTSummaryFile.py --id testinput1 20053 --overwrite

- (Option3): This example will run all files detected in the input folder.

        python3 AutoMakeSSTSummaryFile.py --id all --overwrite

Description of files
--------------------

- Non-Python files:

    filename                          |  description
    ----------------------------------|------------------------------------------------------------------------------------
    README.md                         |  Text file (markdown format) description of the project.

- Python scripts files:

    filename                          |  description
    ----------------------------------|------------------------------------------------------------------------------------
    MakeSSTSummaryFile.py             |  Reads in a SST data file and produces a summary file of the whole run and each block.
    AutoMakeSSTSummaryFile.py            |  Auto-generates SST Summary File from a SST task.

## License

[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

- **[MIT license](http://opensource.org/licenses/mit-license.php)**
- Copyright 2020 © <a href="https://www.nimh.nih.gov/index.shtml" target="_blank">NIMH</a>.
