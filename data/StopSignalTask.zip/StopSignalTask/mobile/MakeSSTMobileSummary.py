def MakeSSTMobileSummary(inFile):
    #!/usr/bin/env python
    # coding: utf-8
    
    # @Author: Kyunghun Lee 
    # Updated: Fri Jan  5 09:50:58 EST 2024 by KL: all pracite-related data/result removed.
    # Updated: Thu Dec 21 08:25:22 EST 2023 by KL: Bug fixed. feature added ('Go % Incorrect','Go % Omission', 'Stop % Incorrect').
    # Updated: Tue Nov  7 15:53:36 EST 2023 by KL
    # Created: Fri Nov  3 23:18:13 EDT 2023
    
    import pandas as pd
    import numpy as np
    
    # Load the Excel file into a DataFrame
    df = pd.read_csv(inFile)  # Modified to read from inFile
    df = pd.read_csv(inFile)  # Modified to read from inFile
    df = pd.read_csv(inFile)  # Modified to read from inFile
    # inFile = 'input/24626_9.6.23_InPerson_S1.csv'
    df = pd.read_csv(inFile)  # Modified to read from inFile
    
    # Remove rows where 'Event' column contains 'Practice'
    df = df[~df['Section'].str.contains('Practice')]
    
    print(df.columns)
    
    # Extract VAS responses
    dict_VAS = {}
    
    # Filter rows where 'Event' contains 'Slider View'
    filtered_df = df[df['Event'].str.contains('Slider View')]
    
    # Extract the name and store the result in a dictionary
    for _, row in filtered_df.iterrows():
        name = (row['Event'].split('Slider View - ')[1]).capitalize()
        if 'Pre_'+name not in dict_VAS:
            dict_VAS['Pre_'+name] = row['User Response']
        elif 'Mid_'+name not in dict_VAS:
            dict_VAS['Mid_'+name] = row['User Response']
        elif 'Post_'+name not in dict_VAS:
            dict_VAS['Post_'+name] = row['User Response']
        else:
            print("Error: More than 3 VAS scores found!")
    
    # Initialize temporary dictionaries to store the sum and counts
    emotion_sums = {}
    emotion_counts = {}
    
    # Process each item in the dictionary to accumulate sums and counts
    for key, value in dict_VAS.items():
        # Isolate the emotion part of the key
        emotion = key.split('_')[1]
        
        # Convert the string value to float for computation
        value = float(value)
        
        # Accumulate sums and counts
        emotion_sums[emotion] = emotion_sums.get(emotion, 0) + value
        emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
    
    # Calculate the averages and update the original dict_VAS with new keys for averages
    for emotion in emotion_sums:
        average_key = f'Avr_{emotion}'
        # Calculate the average and update dict_VAS
        dict_VAS[average_key] = emotion_sums[emotion] / emotion_counts[emotion]
    
    # Output header
    headers = ['SDAN', 'Input File','Home vs InPerson','S1 vs S2',
               # 'Average Practice Go RT', 'Go Practice RT StDev',
           'Average Run Go RT', 'Stop % Accuracy', 'Stop % Incorrect', 'Go % Accuracy', 'Go % Incorrect','Go % Omission','Median Go RT',
           'Average SSD', 'SSRT', 'Post Go Error Go % Accuracy',
           'Post Go Error Go RT', 'Post Go Error Efficiency',
           'Post Any Error Go % Accuracy', 'Post Any Error Go RT',
           'Post Any Error Efficiency', 'Frustration Rating Block 1',
           'Frustration Rating Block 2', 'Frustration Rating Block 3',
           'Frustration Rating Block 4', 'Frustration Rating Block 5',
           'Average Frustration Rating', 'Happiness Rating Block 1',
           'Happiness Rating Block 2', 'Happiness Rating Block 3',
           'Happiness Rating Block 4', 'Happiness Rating Block 5',
           'Average Happiness Rating', 'Include/Exclude']
    
    # Determine which RT to use based on conditions
    conditions = [
        (df['Inhibition'] == 'Inhibit'),
        (df['Inhibition'] == 'Normal')
    ]
    
    # Replace values in 'RT' column with values divided by 1000, only for non-NaN cells
    df['StimulusRT'] = df['StimulusRT'].apply(lambda x: x if not pd.isna(x) else x)
    df['InhibitRT'] = df['InhibitRT'].apply(lambda x: x if not pd.isna(x) else x)
    
    choices = [df['InhibitRT'], df['StimulusRT']]
    df['RT_to_use'] = np.select(conditions, choices, default=pd.NA)
    
    # Convert to numeric, just in case they are not
    df['RT_to_use'] = pd.to_numeric(df['RT_to_use'], errors='coerce')
    
    # Remove rows where 'RT_to_use' is empty
    df = df.dropna(subset=['RT_to_use'])
    
    import pandas as pd
    import numpy as np
    
    # Initialize the result dictionary
    result = {}
    
    # Remove rows where 'Correctness' column is not 'Correct' or 'Incorrect'
    df = df[df['Correctness'].isin(['Correct', 'Incorrect'])]
    
    # Shift the 'Correctness' column down by one to compare with the previous row
    df['Post Error'] = df['Correctness'].shift(1) == 'Incorrect'
    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):
    
    # List of substrings (blocks) you are interested in
    # blocks = ['Practice 1', 'Practice 2', 'Block 1', 'Block 2', 'Block 3', 'Block 4', 'Block 5']
    blocks = ['Block 1', 'Block 2', 'Block 3', 'Block 4', 'Block 5']
    
    # Define a function that takes a section string and returns the block
    def find_block(section):
        for block in blocks:
            if block in section:
                return block
        return None  # Return None or some default value if no block is found
    
    # Apply the function and assign using .loc
    df.loc[:, 'Block'] = df['Section'].apply(find_block)
    df['Block'] = df['Section'].apply(find_block)
    
    # # List of substrings you are interested in
    # substrings = ['Practice 1','Practice 2','Block 1','Block 2','Block 3','Block 4','Block 5']
    
    # # Count the number of rows where 'Section' includes each of the substrings
    # counts = {'# of trials in ' + substring: df['Section'].str.contains(substring).sum() for substring in substrings}
    
    # # Count the number of rows where 'Section' does not include any of the substrings
    # none_count = (~df['Section'].str.contains('|'.join(substrings))).sum()
    
    # # Add the count of none to the dictionary
    # counts['# of trials in others'] = none_count
    
    # # Print out the counts
    # print(counts)
    
    # # Filter the DataFrame for rows where 'Section' includes 'Block 1'
    # block1_df = df[df['Section'].str.contains('Block 1')]
    
    # # Count the number of each different value in the 'Inhibition' column
    # inhibition_counts = block1_df['Inhibition'].value_counts()
    # print(inhibition_counts)
    
    # Existing code to find duplicates
    duplicates = df[df.duplicated(subset=['Block', 'TrialNumber'], keep=False)]
    
    # Count the occurrences of each combination of 'Block' and 'TrialNumber'
    dup_counts = duplicates.groupby(['Block', 'TrialNumber']).size()
    
    # Iterate over each group of duplicates
    for (block, trial), count in dup_counts.items():  # Use .items() instead of .iteritems()
        if count == 2:
            # If there are exactly 2 duplicates, remove the first occurrence
            first_index = df[(df['Block'] == block) & (df['TrialNumber'] == trial)].index[0]
            df = df.drop(first_index)
        elif count > 2:
            # If there are more than 2 duplicates, print an error message
            print(f"Error: More than 2 duplicates found for Block {block} and TrialNumber {trial}")
    
    # Display the modified DataFrame
    
    # Existing code to find duplicates
    duplicates = df[df.duplicated(subset=['Block', 'TrialNumber'], keep=False)]
    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):
    
    # # Calculate average RT and standard deviation
    # average_rt = df['RT_to_use'].mean()
    # std_rt = df['RT_to_use'].std()
    
    # # Filter out rows where RT is more than 3 std dev from the mean
    # df_filtered = df[(df['RT_to_use'] >= (average_rt - 3 * std_rt)) & (df['RT_to_use'] <= (average_rt + 3 * std_rt))]
    
    # # Count included and excluded rows
    # count_included = df_filtered.shape[0]
    # count_excluded = df.shape[0] - count_included
    # df = df_filtered
    # print(count_included)
    # print(count_excluded)
    
    import pandas as pd
    
    # Calculate average RT and standard deviation
    # average_rt = df['RT_to_use'].mean()
    # std_rt = df['RT_to_use'].std()
    # Calculate average and standard deviation only using non-zero values
    average_rt = df.loc[df['RT_to_use'] != 0, 'RT_to_use'].mean()
    std_rt = df.loc[df['RT_to_use'] != 0, 'RT_to_use'].std()
    
    # Define boundaries for filtering
    lower_bound = average_rt - 3 * std_rt
    upper_bound = average_rt + 3 * std_rt
    
    # Filter the DataFrame based on the new conditions
    df_filtered = df[(df['RT_to_use'] == 0) | ((df['RT_to_use'] != 0) & (df['RT_to_use'] >= lower_bound) & (df['RT_to_use'] <= upper_bound))]
    
    # Count included and excluded rows
    count_included = df_filtered.shape[0]
    count_excluded = df.shape[0] - count_included
    
    # Replace the original dataframe with the filtered one
    df = df_filtered
    
    # Print the counts
    print("Count Included:", count_included)
    print("Count Excluded:", count_excluded)
    
    # Adding a new column to df to show the number of standard deviations each row's 'RT_to_use' is from the mean
    df['std_dev_from_mean'] = (df['RT_to_use'] - average_rt) / std_rt
    
    # with pd.option_context('display.max_rows', None, 'display.max_columns', None):
    
    # List of substrings you are interested in
    # substrings = ['Practice 1','Practice 2','Block 1','Block 2','Block 3','Block 4','Block 5']
    substrings = ['Block 1','Block 2','Block 3','Block 4','Block 5']
    
    # Count the number of rows where 'Section' includes each of the substrings
    counts = {'# of trials in ' + substring: df['Section'].str.contains(substring).sum() for substring in substrings}
    
    # Count the number of rows where 'Section' does not include any of the substrings
    none_count = (~df['Section'].str.contains('|'.join(substrings))).sum()
    
    # Add the count of none to the dictionary
    counts['# of trials in others'] = none_count
    
    # Print out the counts
    print(counts)
    
    # # Filter the DataFrame for rows where 'Section' includes 'Block 1'
    # block1_df = df[df['Section'].str.contains('Block 1')]
    
    # # Count the number of each different value in the 'Inhibition' column
    # inhibition_counts = block1_df['Inhibition'].value_counts()
    # print(inhibition_counts)
    
    for i,header in enumerate(headers):
        if header == "SDAN":
            result["SDAN"] = df["SDAN"].iloc[0]
            continue
        elif header == "Input File":
            result[header] = inFile
            continue
        elif header == 'Home vs InPerson':
            if 'athome' in inFile.lower():
                result[header] = "At Home"
            elif 'inperson' in inFile.lower():
                result[header] = "In Person"
            else:
                result[header] = ""
            continue    
        elif header == 'S1 vs S2':
            if 'S1' in inFile:
                result[header] = "S1"
            elif "S2" in inFile:
                result[header] = "S2"
            else:
                result[header] = ""
            continue    
        
        if 'Practice' in header:
            data = df[df['Section'].str.contains('Practice')]
        else:
            data = df[~df['Section'].str.contains('Practice')]
    
        if header == 'Go % Incorrect':
            # Creating a copy of the original DataFrame to avoid altering it
            df_copy = data.copy()
            df_copy = df_copy[df_copy['Inhibition'] == 'Normal']
            
            # Fill empty 'User Response' values in the copied DataFrame using iterrows
            # for i, row in df_copy.iterrows():
            #     if pd.isna(row['User Response']) or row['User Response'] == '':
            #         next_index = df_copy.index[df_copy.index.get_loc(i) + 1] if df_copy.index.get_loc(i) + 1 in df_copy.index else None
            #         if next_index is not None:
            #             df_copy.at[i, 'User Response'] = df_copy.at[next_index, 'User Response']
                        
            # Remove rows where 'User Response' is still empty or NaN
            a = sum(df_copy['Inhibition'] == 'Normal')
            print('# of Go trials:',a)
            df_copy.dropna(subset=['User Response'], inplace=True)
            print('# of Go trials (except trials with no response):',a - sum(df_copy['Inhibition'] == 'Normal'))
                
            # Adjust the condition to count 'Correct' and 'Incorrect' only when 'Inhibition' is 'Normal'
            df_copy['Result'] = 'Not Applicable'
            df_copy.loc[df_copy['Inhibition'] == 'Normal', 'Result'] = (
                ((df_copy['Correct Key'] == '{RIGHTARROW}') & (df_copy['User Response'] == 'Right')) |
                ((df_copy['Correct Key'] == '{LEFTARROW}') & (df_copy['User Response'] == 'Left'))
            ).replace({True: 'Correct', False: 'Incorrect'})
    
            # Debug
            for i, row in df_copy.iterrows():
                if row['Result'] != row['Correctness']:
                    print(row)
                    
            # Recalculate the number of correct and incorrect responses
            correct_count = df_copy[df_copy['Inhibition'] == 'Normal']['Result'].value_counts().get('Correct', 0)
            incorrect_count = df_copy[df_copy['Inhibition'] == 'Normal']['Result'].value_counts().get('Incorrect', 0)
    
            print('# of Go trials (Correct):',correct_count)
            print('# of Go trials (InCorrect except no response):',incorrect_count)
            
            # Recalculate the percentage of incorrect responses
            # result[header] = incorrect_count / (correct_count + incorrect_count) * 100 if (correct_count + incorrect_count) > 0 else 0
            result[header] = incorrect_count / a * 100 if a > 0 else 0
            continue
        elif header == 'Go % Omission':
            # Creating a copy of the original DataFrame to avoid altering it
            df_copy = data.copy()
            df_copy = df_copy[df_copy['Inhibition'] == 'Normal']
                                
            # Remove rows where 'User Response' is still empty or NaN
            a = sum(df_copy['Inhibition'] == 'Normal')
            print('# of Go trials:',a)
            df_copy.dropna(subset=['User Response'], inplace=True)
            b = a - sum(df_copy['Inhibition'] == 'Normal')
            result[header] = b / a * 100 if a > 0 else 0
        
        elif header == 'Stop % Incorrect':
            result[header] = 100 - result['Stop % Accuracy']
            continue    
        
        if 'Post Go Error' in header:
            # Use rows where "Post Error" is True and previous row's "Inhibition" is "Normal"
            post_error_data = data[data['Post Error'] & (data['Inhibition'].shift(1) == 'Normal') & (data['Inhibition'] == 'Normal')]
            if 'Go % Accuracy' in header:
                result[header] = (post_error_data['Correctness'] == 'Correct').sum() / len(post_error_data) * 100
            elif 'Go RT' in header:
                # Filter out rows where 'RT_to_use' is zero
                non_zero_data = post_error_data[post_error_data['RT_to_use'] != 0]
                
                # Calculate the mean of 'RT_to_use' for the non-zero values
                result[header] = non_zero_data['RT_to_use'].mean()
                
            elif 'Efficiency' in header:
                # Calculate Post Go Error Efficiency if data is not empty or NaN
                if pd.notna(result.get("Post Go Error Go % Accuracy")) and pd.notna(result.get("Post Go Error Go RT")):
                    result[header] = result["Post Go Error Go % Accuracy"] / result["Post Go Error Go RT"]
                else:
                    result[header] = " "
            continue
        elif 'Post Any Error' in header:
            # Use rows where "Post Error" is True
            post_any_error_data = data[data['Post Error'] & (data['Inhibition'] == 'Normal')]
            if '% Accuracy' in header:
                result[header] = (post_any_error_data['Correctness'] == 'Correct').sum() / len(post_any_error_data) * 100
            elif 'Go RT' in header:
                # Use only non-zero
                non_zero_post_any_error = post_any_error_data[post_any_error_data['RT_to_use'] != 0]
                # result[header] = post_any_error_data['RT_to_use'].mean()
                result[header] = non_zero_post_any_error['RT_to_use'].mean()
            elif 'Efficiency' in header:
                if pd.notna(result.get("Post Any Error Go % Accuracy")) and pd.notna(result.get("Post Any Error Go RT")):
                    result[header] = result["Post Any Error Go % Accuracy"] / result["Post Any Error Go RT"] 
                else:
                    result[header] = " "
            continue
            
        if 'Go' in header:
            # Use rows where "Inhibition" column is "Normal"
            data = data[data['Inhibition'] == 'Normal']
        elif 'Stop' in header:
            # Use rows where "Inhibition" column is "Inhibit"
            data = data[data['Inhibition'] == 'Inhibit']
        # else:
        #     # Use all rows
        #     data = data
    
        # if 'Average' in header and 'RT' in header:
        #     # Calculate average of 'RT_to_use' column
        #     result[header] = data['RT_to_use'].mean()
        if 'Average' in header and 'RT' in header:
            non_zero_data = data[data['RT_to_use'] != 0]
            result[header] = non_zero_data['RT_to_use'].mean()
        # elif 'Median' in header and 'RT' in header:
            # Calculate median of 'RT_to_use' column
            # Temporarily set options to display the entire DataFrame
            # with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                # print(data['RT_to_use'])
    
            # # Count the number of zeros
            # num_zeros = (data['RT_to_use'] == 0).sum()
            # print("Number of zeros:", num_zeros)
            # print("Number of all:", (data['RT_to_use'] > -100000).sum())
            # print(data['RT_to_use'].median())
            
            # result[header] = data['RT_to_use'].median()
        elif 'Median' in header and 'RT' in header:
            non_zero_data = data[data['RT_to_use'] != 0]
            result[header] = non_zero_data['RT_to_use'].median()
        elif '% Accuracy' in header:
            # Calculate accuracy
            result[header] = (data['Correctness'] == 'Correct').sum() / len(data) * 100 if len(data) > 0 else np.nan
        elif header == 'Average SSD':
            # Calculate average of StimulusDuration column using only rows where "Inhibition" is "Inhibit"
            inhibit_data = data[data['Inhibition'] == 'Inhibit']
            result[header] = inhibit_data['StimulusDuration'].mean()
        elif header == 'SSRT':
            # Calculate SSRT
            result[header] = result.get("Median Go RT", np.nan) - result.get("Average SSD", np.nan)
        elif header == "Post Go Error Efficiency":
            # Calculate Post Go Error Efficiency if data is not empty or NaN
            if pd.notna(result.get("Post Go Error Go % Accuracy")) and pd.notna(result.get("Post Go Error Go RT")):
                result[header] = result["Post Go Error Go % Accuracy"] / result["Post Go Error Go RT"]
            else:
                result[header] = " "
        elif header == "Post Any Error Efficiency":
            if pd.notna(result.get("Post Any Error Go % Accuracy")) and pd.notna(result.get("Post Any Error Go RT")):
                result[header] = result["Post Any Error Go % Accuracy"] / result["Post Any Error Go RT"]
            else:
                result[header] = " "
        elif header == "Include/Exclude":
            # Check if all blocks are present (1,2,3,4,5)
            blocks_present = all(data['Section'].str.contains(f'Block {i}').any() for i in range(1, 6))
    
            # Calculate the percentage of 'Correct' in 'Normal' Inhibition rows
            normal_rows = data[data['Inhibition'] == 'Normal']
            normal_correct_percentage = (normal_rows['Correctness'] == 'Correct').sum() / len(normal_rows) * 100 if len(normal_rows) > 0 else 0
            result['normal_correct_percentage'] = normal_correct_percentage
            
            # Calculate the percentage of 'Correct' in 'Inhibit' Inhibition rows
            inhibit_rows = data[data['Inhibition'] == 'Inhibit']
            # inhibit_correct_percentage = (inhibit_rows['Correctness'] == 'Correct').sum() / len(inhibit_rows) * 100 if len(inhibit_rows) > 0 else 0
            # result['inhibit_correct_percentage'] = inhibit_correct_percentage
            inhibit_correct_number = (inhibit_rows['Correctness'] == 'Correct').sum() if len(inhibit_rows) > 0 else 0
    
            # Decide to 'Include' or 'Exclude' based on conditions
            if blocks_present and normal_correct_percentage >= 60 and inhibit_correct_number >= 30:
                result[header] = "Include"
            else:
                result[header] = "Exclude"
        elif "Post Go Error" in header:
            # Use rows where "Post Error" is True and previous row's "Inhibition" is "Normal"
            post_error_data = data[data['Post Error'] & (data['Inhibition'].shift(1) == 'Normal')]
            if 'Go % Accuracy' in header:
                result[header] = post_error_data['Correctness'] == 'Correct'.sum() / len(post_error_data) * 100
            # elif 'Go RT' in header:
            #     result[header] = post_error_data['RT_to_use'].mean()
            elif 'Go RT' in header:
                non_zero_post_error = post_error_data[post_error_data['RT_to_use'] != 0]
                result[header] = non_zero_post_error['RT_to_use'].mean()
        
        elif "Post Any Error" in header:
            # Use rows where "Post Error" is True
            post_any_error_data = data[data['Post Error']]
            if '% Accuracy' in header:
                result[header] = post_any_error_data['Correctness'] == 'Correct'.sum() / len(post_any_error_data) * 100
            # elif 'Go RT' in header:
            #     result[header] = post_any_error_data['RT_to_use'].mean()
            elif 'Go RT' in header:
                non_zero_post_any_error = post_any_error_data[post_any_error_data['RT_to_use'] != 0]
                result[header] = non_zero_post_any_error['RT_to_use'].mean()
    
        elif "Error Go RT" in header:
            # Calculate average of 'RT_to_use' where there is an error
            error_data = data[data['Correctness'] == 'Incorrect']
            # result[header] = error_data['RT_to_use'].mean()
            non_zero_error_data = error_data[error_data['RT_to_use'] != 0]
            result[header] = non_zero_error_data['RT_to_use'].mean()
    
    # Concatenate result and dict_VAS.
    result.update(dict_VAS)
    result['count_included'] = count_included
    result['count_excluded'] = count_excluded
    result.update(counts)
    
    print(result['Go % Accuracy'] + result['Go % Incorrect'] + result['Go % Omission'])
    
    from datetime import datetime
    import os
    
    series = pd.Series(result)
    df_result = series.to_frame().transpose()
    
    # Get the current date and time
    now = datetime.now()
    
    # Format the current date and time as a string, e.g., "20230926_142530"
    datetime_str = now.strftime('%Y%m%d_%H%M%S')
    
    # Construct the filename using the date and time string<?xml version="1.0" encoding="UTF-8"?>
    filename = f'sst_mobile_summary_{datetime_str}.csv'
    
    # Save the DataFrame to a CSV file with the constructed filename
    return df_result # Modified to save to outFile
    
    # Assume the directory you want to save in is the current working directory
    directory = os.getcwd()
    
    # Create the absolute path
    absolute_file_path = os.path.abspath(os.path.join(directory, filename))
    
    # Now absolute_file_path contains the absolute path to the file
    print(absolute_file_path)
    
