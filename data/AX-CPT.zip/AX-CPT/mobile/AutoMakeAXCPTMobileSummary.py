import os
import sys
import wx
import datetime
import glob
from MakeAXCPTMobileSummary import MakeAXCPTMobileSummary
import pandas as pd

class MyFrame(wx.Frame):
    def __init__(self, input_folder=None):
        super().__init__(parent=None, title='Input/Output Selector', size=(800, 300))
        self.panel = wx.Panel(self)
        self.my_sizer = wx.BoxSizer(wx.VERTICAL)
        self.input_folder = input_folder if input_folder else os.getcwd()
        self.create_widgets()
        self.input_path = None
        self.output_folder = None
        self.output_file_name = None
        self.Show()

    def create_widgets(self):

        # Input Folder Widgets
        self.input_txt = self.add_folder_selection("Input Folder:", self.input_folder, self.on_browse_input)
        # self.add_folder_selection("Input Folder:", self.input_folder, self.on_browse_input)

        # Output Folder Widgets
        default_output_folder = os.path.join(self.input_folder, "output")
        # self.add_folder_selection("Output Folder:", default_output_folder, self.on_browse_output)
        self.output_txt = self.add_folder_selection("Output Folder:", default_output_folder, self.on_browse_output)

        # Output File Name
        self.output_lbl = wx.StaticText(self.panel, label='Output File Name:')
        self.my_sizer.Add(self.output_lbl, 0, wx.ALL, 5)
        default_output_name = f"output-summary-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
        self.output_name_txt = wx.TextCtrl(self.panel, value=default_output_name)
        self.my_sizer.Add(self.output_name_txt, 0, wx.ALL | wx.EXPAND, 5)

        # Submit Button
        self.ok_btn = wx.Button(self.panel, label='Submit')
        self.ok_btn.Bind(wx.EVT_BUTTON, self.on_submit)
        self.my_sizer.Add(self.ok_btn, 0, wx.ALL | wx.CENTER, 5)
        self.panel.SetSizer(self.my_sizer)

    def add_folder_selection(self, label, default_path, on_browse_method):
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        lbl = wx.StaticText(self.panel, label=label)
        self.my_sizer.Add(lbl, 0, wx.ALL, 5)
        txt = wx.TextCtrl(self.panel, value=default_path)
        sizer.Add(txt, 1, wx.EXPAND | wx.ALL, 5)
        browse_btn = wx.Button(self.panel, label='Browse...')
        browse_btn.Bind(wx.EVT_BUTTON, on_browse_method)
        sizer.Add(browse_btn, 0, wx.ALL, 5)
        self.my_sizer.Add(sizer, 0, wx.EXPAND)
        return txt

    def on_browse_input(self, event):
        with wx.DirDialog(self, "Choose Input Directory", style=wx.DD_DEFAULT_STYLE | wx.DD_DIR_MUST_EXIST) as dialog:
            if dialog.ShowModal() == wx.ID_OK:
                self.input_txt.SetValue(dialog.GetPath())

    def on_browse_output(self, event):
        with wx.DirDialog(self, "Choose Output Directory", style=wx.DD_DEFAULT_STYLE | wx.DD_DIR_MUST_EXIST) as dialog:
            if dialog.ShowModal() == wx.ID_OK:
                self.output_txt.SetValue(dialog.GetPath())

    def on_submit(self, event):
        self.input_path = self.input_txt.GetValue()
        self.output_folder = self.output_txt.GetValue()
        self.output_file_name = self.output_name_txt.GetValue()
        self.output_path = os.path.join(self.output_folder, self.output_file_name)
        # print(f"Input Folder: {self.input_path}")
        # print(f"Output File: {self.output_path}")
        self.Close()
drivesToCheck = ['Z:', 'Y:', 'X:', 'W:', 'V:', 'U:', 'T:', 'S:', '/Volumes/sdan1','/Volumes/sdan-edb/','/Volumes/']
drivePath = '';  # path to shared drive
detected = False
for drive in drivesToCheck:
    projectDir = '%s/Data/Mobile Tasks Pilot/Data/TAP-IT' % drive
    # print(projectDir)
    if os.path.exists(projectDir):
       drivePath = drive  # path to shared drive
       print('Path to data detected: %s' % drivePath)
       print('Project Data Directory: %s' % projectDir)
       break
    drive = drive + "/SDAN1"
    projectDir = '%s/Data/Mobile Tasks Pilot/Data/TAP-IT' % drive
    # print(projectDir)
    if os.path.exists(projectDir):
       drivePath = drive  # path to shared drive
       print('Path to data detected: %s' % drivePath)
       print('Project Data Directory: %s' % projectDir)
       detected = True
       break


# Define the main function to handle automation
def AutoMakeSSTMobileSummary(input_folder, output_file):
    # Get a list of all CSV files in the input directory and all subdirectories
    input_files = glob.glob(os.path.join(input_folder, '**', '*.csv'), recursive=True)

    # Initialize an empty list to collect DataFrames
    results = []

    # Process each file and store the result in the list
    for file in input_files:
        if "output-summary" in file:
            continue
        result_df = MakeAXCPTMobileSummary(file)
        results.append(result_df)

    # Concatenate all results into a single DataFrame
    final_result = pd.concat(results, ignore_index=True)

    # Save the concatenated DataFrame to the output file
    final_result.to_csv(output_file, index=False)
    print(f"Processed {len(input_files)} files. Results are saved in {output_file}")

input_folder = "" if detected == False else projectDir

app = wx.App(False)

# Manually entered input folder. If empty, current directory will be used.
# input_folder = "/Volumes/sdan-edb//SDAN1"  # Replace with your path or keep empty for the current directory

frame = MyFrame(input_folder=input_folder)
app.MainLoop()

# After the window is closed, access the paths if you need
input_folder = frame.input_path
output_path = frame.output_path
# print(input_folder)
# print(output_path)
AutoMakeSSTMobileSummary(input_folder, output_path)

# if __name__ == "__main__":
#     # Check if the correct number of arguments are provided
#     if len(sys.argv) != 3:
#         print("Usage: python AutoMakeSSTMobileSummary.py <input_folder_path> <output_file_path>")
#         sys.exit(1)
#
#     # Parse input arguments
#     input_folder_path = sys.argv[1]
#     output_file_path = sys.argv[2]
#
#     # Run the automation function
#     AutoMakeSSTMobileSummary(input_folder_path, output_file_path)